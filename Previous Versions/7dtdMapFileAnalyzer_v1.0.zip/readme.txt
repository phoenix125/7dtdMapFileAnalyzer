7dtdMapFileAnalyzer - A Utility to analyze and compare the number of POIs in your map(s)!
- Latest version: 7dtdMapFileAnalyzer_v1.0.0 (2019-03-01)
- By Phoenix125 | http://www.Phoenix125.com | http://discord.gg/EU7pzPs | kim@kim125.com

----------
 FEATURES
----------
- Fully customizable.
- Creates two files: 
	1. A .txt file for quick easy analysis
	2. A .csv file for importing into your favorite Office program.
- It can automatically add each test run to the .csv file for direct comparison and easy importing.

--------------
 INSTRUCTIONS
--------------
- Run 7dtdMapFileAnalyzer.exe. It will create 7dtdMapFileAnalyzer.ini.
- Open 7dtdMapFileAnalyzer.ini with Notepad (or any text editor).. Notepad++ is preferred.
- Modify the first section to match your file and folder locations.
  (OPTIONAL) Modify the lower section to change what information to compare with.
- Rerun 7dtdMapFileAnalyzer.exe
DONE!
- It will create the two files as described above.

Thank you!

----------------
 DOWNLOAD LINKS
----------------
Source Code (AutoIT): https://github.com/phoenix125/7dtdMapFileAnalyzer
GitHub:	              https://github.com/phoenix125/7dtdMapFileAnalyzer

Website: http://www.Phoenix125.com
Discord: http://discord.gg/EU7pzPs
Forum:   https://phoenix125.createaforum.com/index.php

-----------------
 VERSION HISTORY
-----------------
(2019-03-01) v1.0.0 Inital release
- Fully customizable.
- Creates two files: 
	1. A .txt file for quick easy analysis
	2. A .csv file for importing into your favorite Office program.
- It can automatically add each test run to the .csv file for direct comparison and easy importing.
